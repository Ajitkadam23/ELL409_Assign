# ELL409_Assign
This code is implementation of Backpropagation algorithm.\
-When code is run it asks user to enter number of hidden nodes ,learning rate and number of epochs\
-corrosponding to each epoch code wile print output rms error for all training set\
Discription of code:\
-initially code will import required libraries and then it has one class and one subclass \

-first class name is "NeuralNetwork" it is initialisation of neural network with required parameters \  
            -second class name is "train_net" which trains the training data in "train()" method and simulteniously updates the weights of nural 
network using Backpropagation algorithm\
-in the "train_net" class evaluate and evaluateT methods examines the training and testing samples




